A simple package to gen a color scheme by scraping coolors.co

to use import coolor function and run
